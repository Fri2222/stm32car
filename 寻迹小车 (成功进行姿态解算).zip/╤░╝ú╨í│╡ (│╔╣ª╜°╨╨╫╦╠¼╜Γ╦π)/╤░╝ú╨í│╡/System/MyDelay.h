#ifndef __MYDELAY_H
#define __MYDELAY_H

void MyDelay_us(uint32_t us);
void MyDelay_ms(uint32_t ms);
void MyDelay_s(uint32_t s);

#endif
