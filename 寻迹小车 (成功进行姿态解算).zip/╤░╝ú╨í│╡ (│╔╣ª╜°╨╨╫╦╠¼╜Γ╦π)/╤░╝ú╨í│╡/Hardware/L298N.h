#ifndef __L298N_H
#define __L298N_H
void L298N_Init(void);
void L298N_Left_SetSpeed(int8_t Speed);
void L298N_Right_SetSpeed(int8_t Speed);
void L298N_Stop(void);
#endif
