#ifndef __PWM_H
#define __PWM_H

void PWM_Init(void);
void PWM_1_SetCompare1(uint16_t Compare);
void PWM_2_SetCompare1(uint16_t Compare);
void PWM_1_Init(void);
void PWM_2_Init(void);
#endif
