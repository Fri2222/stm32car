#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "L298N.h"
#include "MyDelay.h"
#include "Buzzer.h"
#include "LightSensor.h"
#include "PWM.h"
#include "Motor.h"
#include "AD.h"
#include "Encoder.h"
#include "Control.h"
#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "mpu6050.h"  
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h" 
#include "OLED.h"
int16_t Left_Speed;
int16_t Right_Speed;
int main(void)
{
	
	float pitch,roll,yaw; 		//Å·À­½Ç

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	 //ÉèÖÃNVICÖÐ¶Ï·Ö×é2:2Î»ÇÀÕ¼ÓÅÏÈ¼¶£¬2Î»ÏìÓ¦ÓÅÏÈ¼¶
	uart_init(115200);	 	//´®¿Ú³õÊ¼»¯Îª115200
	delay_init();	//ÑÓÊ±³õÊ¼»¯ 
	LED_Init();		  			//³õÊ¼»¯ÓëLEDÁ¬½ÓµÄÓ²¼þ½Ó¿Ú
	MPU_Init();					//³õÊ¼»¯MPU6050
	OLED_Init();

	while(mpu_dmp_init())
	{
	delay_ms(20);
	}
	while(1)
	{
		delay_ms(2);
		if(mpu_dmp_get_data(&pitch,&roll,&yaw)==0)
		{
		OLED_ShowSignedNum(2, 1, pitch, 5);					//OLED????
		OLED_ShowSignedNum(3, 1, roll, 5);
		OLED_ShowSignedNum(4, 1, yaw, 5);
		}
		printf("%f,%f,%f\r\n",pitch,roll,yaw);
	} 	

}
/**
  * 函    数：TIM4中断函数
  * 参    数：无
  * 返 回 值：无
  * 注意事项：此函数为中断函数，无需调用，中断触发后自动执行
  *           函数名为预留的指定名称，可以从启动文件复制
  *           请确保函数名正确，不能有任何差异，否则中断函数将不能进入
  */
void TIM4_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)		//判断是否是TIM4的更新事件触发的中断
	{
		Left_Speed = Read_Encoder_TIM4();								//每隔固定时间段读取一次编码器计数增量值，即为速度值
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);			//清除TIM4更新事件的中断标志位
															//中断标志位必须清除
															//否则中断将连续不断地触发，导致主程序卡死
				OLED_ShowNum(1, 8, Left_Speed, 5);	

	}
}
/**
  * 函    数：TIM3中断函数
  * 参    数：无
  * 返 回 值：无
  * 注意事项：此函数为中断函数，无需调用，中断触发后自动执行
  *           函数名为预留的指定名称，可以从启动文件复制
  *           请确保函数名正确，不能有任何差异，否则中断函数将不能进入
  */
void TIM3_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)		//判断是否是TIM3的更新事件触发的中断
	{
		Right_Speed = Read_Encoder_TIM3();								//每隔固定时间段读取一次编码器计数增量值，即为速度值
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);			//清除TIM3更新事件的中断标志位
															//中断标志位必须清除
							OLED_ShowNum(2, 8, Right_Speed, 5);		//显示转换结果第3个数据
										//否则中断将连续不断地触发，导致主程序卡死
	}
}
