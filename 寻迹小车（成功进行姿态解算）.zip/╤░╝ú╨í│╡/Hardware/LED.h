#ifndef __LED_H
#define __LED_H
void LED_Init(void);
void LED_OFF(uint16_t GPIO_Pin_x);
void LED_ON(uint16_t GPIO_Pin_x);
void LED_Turn (uint16_t GPIO_Pin_x);
#endif
