#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"
#include "Motor.h"
#include <stdlib.h>
#define PI 3.14159265
#define ZHONGZHI 3085
int Incremental_PI (int Encoder,int Target);
int Position_PID (uint16_t AD_0,uint16_t target);
uint8_t Quantize_0(uint16_t adc_value);
#endif
