#ifndef __SERIAL_H
#define __SERIAL_H

void Serial_Init(void);
extern char Cx,Cy,Cz;
                               
#endif                         
